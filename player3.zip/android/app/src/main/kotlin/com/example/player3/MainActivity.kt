package com.example.player3

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
